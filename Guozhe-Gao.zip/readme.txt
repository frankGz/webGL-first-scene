All the required elements are implemented successfully, include:

Ground box
Two rocks
Seaweed * 3
Fish